export default {
  type: "service_account",
  project_id: "morphine-c575e",
  private_key_id: "b2e087c9e567bfaa757c1d5e632696853c03b8d7",
  // tslint:disable-next-line:max-line-length
  private_key: "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDk/3ogG5Fbb0+i\n6QazX49cepwubwz4xNxxtIXu7gUVP3PPmtOipYFQbf0A4NsDbm+CL9Ak0Ozo87yZ\nuveH9wQNcQfiEtvWothBL/qyGBRc+rerCYlZAsOtviUQ3I4qF/PEpc+dbGFGJsW0\nAWjyh2VoiP4B5uLqZWnqyxmjPOCITZFCLGCDmvSQdL4x3WJ/Qn6rzPRy1OfNMyEO\nI+JP9silirkd0UZ1luDwC8OjMAIbBCj1F1Atgho0j0Kp+C52kS7ZrqvKVY4VM3az\nq3Rk62mVVqEuW7iCOIMbi6IiZaUDwvD1sge6ojV8iEcAeRQbaC+rdgtLzZouvgyf\nesJaVvYfAgMBAAECggEAGn83Ldo9a6jfEZjItjOjSSOaHm3/axTi9GMw23sov73Q\n/t90Mo3XqdX4NZmkWJV24Jz7XBndTSfQFbJXwaCYPvKVDhh5iIXc46S+FiJez31m\niCtj0ZardqyZlFsONhpXEf96R5sKobfgc291qcPMkkJxBbOmDlIqux4XZYHTRzde\nYf3JTNl5eftYVPfo3ysHTH1mhf4WB0zcrwkQ8L9IsaszWu2Bbt+CqvER7/yPplBh\njEVrL/yX1w1KAZxf3PQYcukMW/MzinlQ7YuevSO1kB9UyyFoTiuJYj+TkrEwCdxX\nJRBu8qg7cHSF5Q+DSYoJDI1ydiIT2nJS6TH9dZNvNQKBgQD8r6CMKeqhDkMJ+qKc\nsXRL2jVyDfguB/R58jBCofKqicSondNaxKf2En082OsIMACZ/lJ1CIHp/ks5k5xM\nuf0wMxK3BOphzQpe9iYEcjyguBzUy5C47ENwVAd2VM0sT7HEj+Qi84FBr1Vqhuem\n3vLYoVqzOAFTidfQrpEwL1oAIwKBgQDoAFGvylgv96uRpa+6/ihGM429xibjR+9h\nr/K/MFXG5j26XX6xgYmd2gEHoo7DXiL50TaV+E49RCRYWHaJDr5FGChbNQ1LkJ4k\n4gNZRSKcSRVrmDWzkbWCTcWAMnbZ3DAnGcmjvmVclrf0mTWAINDUWZB4am2FRCgx\nWIFS2cjT1QKBgQDqgri2vMQzuv++yCyYzhyHtTl647ocRme/sWTWwmRrn7azYt5f\n1Dmpp5kxmoPuslYslRrD4SRpHQeFpRgfIVH4pL3Ou7InGFtyrHG2GKtp4dVoLJDg\n/uzL2ECgsq1EXaY3Le/l/CZO5sGYPyHI/gtVv9JkmCqq9DgmRY0bsiaODwKBgQDP\nNem/nnQhc43zag6IbxQ9jzIbu21kNg2iLGodROh325BqcbMEi3QEXn/o99GWwO9w\nPOIKFFqc8c2ccnZ8d4SNZcQ1oi6bvTDiNFNVWiBNgiD1ll7wYUXCef/aPjhU4QrJ\nAYlNDHKvvZXTiztzktuxrcURJ81l57gWSrxG6WkreQKBgF/BR/VpuCBx3oxEkXZ0\nj2CqSEgM7ooWZfqiLY1xeAsBGuCQmCgOiXPVUkADhFb37QRnv6GyODnW4vpvTBZr\nUTbQ9DSFG8ryyUGb4w6fqGqiDGUjm7v0y+HaoWVAqcmsDpAwlCnPZX4x5KgD0Y5B\nyyUOHnV+IRemOxvnMSxrY6j0\n-----END PRIVATE KEY-----\n",
  client_email: "firebase-adminsdk-bl36k@morphine-c575e.iam.gserviceaccount.com",
  client_id: "114786516302143513230",
  auth_uri: "https://accounts.google.com/o/oauth2/auth",
  token_uri: "https://oauth2.googleapis.com/token",
  auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
  // tslint:disable-next-line:max-line-length
  client_x509_cert_url: "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-bl36k%40morphine-c575e.iam.gserviceaccount.com"
};
